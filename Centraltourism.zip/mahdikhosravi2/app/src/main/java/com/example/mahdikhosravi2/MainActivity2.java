package com.example.mahdikhosravi2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {


    String [] list = {"اراک","خمین","محلات"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        ListView listView = findViewById(R.id.listview);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,R.layout.list_style,R.id.textViewStyle,list);
        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                if (i==0) {
                    Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                    intent.putExtra("name","اراک");
                    startActivities(new Intent[]{intent});
                    Toast.makeText(MainActivity2.this, "اراک", Toast.LENGTH_SHORT).show();
                } else if (i == 1) {
                    Intent intent2 = new Intent(MainActivity2.this, MainActivity3.class);
                    intent2.putExtra("name", "خمین");
                    startActivities(new Intent[]{intent2});
                    Toast.makeText(MainActivity2.this, "خمین", Toast.LENGTH_SHORT).show();
                } else if (i == 2) {
                    Intent intent3 = new Intent(MainActivity2.this, MainActivity3.class);
                    intent3.putExtra("name", "محلات");
                    startActivities(new Intent[]{intent3});
                    Toast.makeText(MainActivity2.this, "محلات", Toast.LENGTH_SHORT).show();

                }

            }



        });


    }


}