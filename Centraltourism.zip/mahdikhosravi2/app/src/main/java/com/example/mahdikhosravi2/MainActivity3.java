package com.example.mahdikhosravi2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        TextView textView = findViewById(R.id.textView);
        TextView text = findViewById(R.id.textViewtext);
        ImageView img = findViewById(R.id.imageView);

        Intent recive = getIntent();
        String name = recive.getStringExtra("name");

        if (name.equals("اراک")) {
            textView.setText("آشنایی با شهر اراک");
        } else if (name.equals("خمین")) {
            textView.setText("آشنایی با شهرستان خمین");
        } else if (name.equals("محلات")) {
            textView.setText("آشنایی با شهرستان محلات");
        }


        if (name.equals("اراک")) {
            text.setText("اراک یکی از کلان شهرهای ایران، از بزرگ ترین شهرهای مرکز ایران و مرکز استان مرکزی و شهرستان اراک است. جمعیت اراک در سال ۱۳۹۵ خورشیدی برابر با ۵۲۰٬۹۴۴ نفر بوده که از این نظر قطب جمعیتی استان مرکزی و هجدهمین شهر پرجمعیت ایران به حساب می آید.");
        } else if (name.equals("خمین")) {
            text.setText("خمین یکی از شهرهای استان مرکزی است که در جنوبی ترین قسمت این استان و در فاصله ۳۲۰ کیلومتری از تهران واقع شده است. این شهر زادگاه روح الله موسوی خمینی، رهبر انقلاب سال ۱۳۵۷ ایران و بنیان گذار جمهوری اسلامی است.");
        } else if (name.equals("محلات")) {
            text.setText("محلات مَحَلّات شهری از توابع بخش مرکزی شهرستان محلات و مرکز شهرستان محلات استان مرکزی می باشد.به طور خلاصه این شهر به پایتخت گل ایران معروف است و قطب پرورش گل داوودی است.سوغات این شهر حلوا ارده است.");
        }


        if (name.equals("خمین")) {
            img.setImageDrawable(getResources().getDrawable(R.drawable.khomein));
        } else if (name.equals("محلات")) {
            img.setImageDrawable(getResources().getDrawable(R.drawable.mahalat));
        }


    }
}